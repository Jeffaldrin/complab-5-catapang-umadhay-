const amqp = require('amqplib');

const BROKER_URL = process.env.BROKER_URL || 'amqp://guest:guest@localhost:5672';
const QUEUE_NAME = 'inventory_service_queue';

async function start() {
  try {
    const connection = await amqp.connect(BROKER_URL);
    const channel = await connection.createChannel();

    // Assert the fanout exchange and bind our queue
    await channel.assertExchange('order_exchange', 'fanout', { durable: true });
    await channel.assertQueue(QUEUE_NAME, { durable: true });
    await channel.bindQueue(QUEUE_NAME, 'order_exchange', '');

    // Process only one message at a time
    channel.prefetch(1);

    console.log(`[Inventory Service] Waiting for messages on ${QUEUE_NAME}...`);

    channel.consume(QUEUE_NAME, (msg) => {
      if (msg !== null) {
        const order = JSON.parse(msg.content.toString());
        console.log(`[Inventory Service] Processing order ${order.id}`);
        console.log(`  → Reserving ${order.quantity} unit(s) of "${order.product}"`);

        // Simulate work
        setTimeout(() => {
          console.log(`[Inventory Service] Inventory updated for order ${order.id}`);
          channel.ack(msg);
        }, 500);
      }
    });
  } catch (err) {
    console.error('[Inventory Service] Error:', err.message);
    setTimeout(start, 5000); // retry connection
  }
}

start();
