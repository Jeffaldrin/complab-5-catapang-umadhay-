const amqp = require('amqplib');

const BROKER_URL = process.env.BROKER_URL || 'amqp://guest:guest@localhost:5672';
const QUEUE_NAME = 'notification_service_queue';

async function start() {
  try {
    const connection = await amqp.connect(BROKER_URL);
    const channel = await connection.createChannel();

    await channel.assertExchange('order_exchange', 'fanout', { durable: true });
    await channel.assertQueue(QUEUE_NAME, { durable: true });
    await channel.bindQueue(QUEUE_NAME, 'order_exchange', '');

    channel.prefetch(1);

    console.log(`[Notification Service] Waiting for messages on ${QUEUE_NAME}...`);

    channel.consume(QUEUE_NAME, (msg) => {
      if (msg !== null) {
        const order = JSON.parse(msg.content.toString());
        console.log(`[Notification Service] Sending notification for order ${order.id}`);
        console.log(`  → Email/SMS to customer "${order.customer}" about "${order.product}"`);

        setTimeout(() => {
          console.log(`[Notification Service] Notification sent for order ${order.id}`);
          channel.ack(msg);
        }, 300);
      }
    });
  } catch (err) {
    console.error('[Notification Service] Error:', err.message);
    setTimeout(start, 5000);
  }
}

start();
