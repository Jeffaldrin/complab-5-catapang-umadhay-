const amqp = require('amqplib');

const BROKER_URL = process.env.BROKER_URL || 'amqp://guest:guest@localhost:5672';
const QUEUE_NAME = 'payment_service_queue';

async function start() {
  try {
    const connection = await amqp.connect(BROKER_URL);
    const channel = await connection.createChannel();

    await channel.assertExchange('order_exchange', 'fanout', { durable: true });
    await channel.assertQueue(QUEUE_NAME, { durable: true });
    await channel.bindQueue(QUEUE_NAME, 'order_exchange', '');

    channel.prefetch(1);

    console.log(`[Payment Service] Waiting for messages on ${QUEUE_NAME}...`);

    channel.consume(QUEUE_NAME, (msg) => {
      if (msg !== null) {
        const order = JSON.parse(msg.content.toString());
        console.log(`[Payment Service] Processing payment for order ${order.id}`);
        console.log(`  → Charging $${order.amount} for "${order.product}"`);

        setTimeout(() => {
          console.log(`[Payment Service] Payment successful for order ${order.id}`);
          channel.ack(msg);
        }, 700);
      }
    });
  } catch (err) {
    console.error('[Payment Service] Error:', err.message);
    setTimeout(start, 5000);
  }
}

start();
