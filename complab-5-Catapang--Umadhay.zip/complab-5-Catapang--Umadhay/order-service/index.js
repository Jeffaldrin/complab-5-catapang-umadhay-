const express = require('express');
const cors = require('cors');
const amqp = require('amqplib');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = 3000;
const BROKER_URL = process.env.BROKER_URL || 'amqp://guest:guest@localhost:5672';

app.use(cors());
app.use(express.json());

let channel = null;

async function connectRabbitMQ() {
  try {
    const connection = await amqp.connect(BROKER_URL);
    channel = await connection.createChannel();

    // Declare a fanout exchange so all bound queues receive the message
    await channel.assertExchange('order_exchange', 'fanout', { durable: true });

    console.log('Connected to RabbitMQ and declared order_exchange');
  } catch (err) {
    console.error('Failed to connect to RabbitMQ:', err.message);
    setTimeout(connectRabbitMQ, 5000); // retry
  }
}

connectRabbitMQ();

// Create a new order
app.post('/orders', async (req, res) => {
  try {
    if (!channel) {
      return res.status(503).json({ error: 'Message broker not ready' });
    }

    const order = {
      id: uuidv4(),
      product: req.body.product || 'Unknown Product',
      quantity: req.body.quantity || 1,
      customer: req.body.customer || 'Guest',
      amount: req.body.amount || 100,
      createdAt: new Date().toISOString()
    };

    const message = Buffer.from(JSON.stringify(order));

    // Publish to fanout exchange (all queues will receive a copy)
    channel.publish('order_exchange', '', message, { persistent: true });

    console.log(`[Order Service] Published order ${order.id}`);

    res.status(201).json({
      message: 'Order created and published successfully',
      order
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create order' });
  }
});

app.get('/health', (req, res) => {
  res.json({ status: 'Order Service is running', rabbitmq: !!channel });
});

app.listen(PORT, () => {
  console.log(`Order Service listening on port ${PORT}`);
});
